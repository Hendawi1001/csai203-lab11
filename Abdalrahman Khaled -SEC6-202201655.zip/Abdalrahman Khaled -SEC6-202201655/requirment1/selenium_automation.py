from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))

try:
    driver.maximize_window()
    driver.get('https://www.amazon.eg/?language=en_AE')
    search_bar = WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.ID, 'twotabsearchtextbox'))
    )

    search_term = 'iphone 15 pro max case'
    search_bar.send_keys(search_term)
    search_bar.send_keys(Keys.RETURN)

    first_product = WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.CSS_SELECTOR, 'div.s-main-slot div[data-component-type="s-search-result"]'))
    )
    first_product.click()

    WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.ID, 'productTitle'))
    )

    product_title = driver.find_element(By.ID, 'productTitle').text
    print("Product Title:", product_title)

    product_url = driver.current_url
    print("Product URL:", product_url)

    try:
        product_price = driver.find_element(By.CSS_SELECTOR, '#corePrice_feature_div > div > div > span.a-price.aok-align-center > span:nth-child(2) > span.a-price-whole').text
        print("Product Price:", product_price)
    except:
        print("Product Price: Not available")

    try:
        product_rating = driver.find_element(By.CSS_SELECTOR, 'span[data-hook="rating-out-of-text"]').text
        print("Product Rating:", product_rating)
    except:
        print("Product Rating: Not available")

    screenshot_name = f'{search_term}_product_page_screenshot.png'
    driver.save_screenshot(screenshot_name)
    print(f"Screenshot saved as '{screenshot_name}'.")

    time.sleep(5)

finally:
    driver.quit()
