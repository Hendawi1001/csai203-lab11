from seleniumbase import BaseCase
from seleniumbase import SB  #so i used SB
import time
class ToDoListTests(BaseCase):#was not working because of pytest
    def test_add_task(self):
        self.open("http://127.0.0.1:5000/")  
        task_description = "hello,im abdalrahman"
        self.type("input[name='task']", task_description)  
        self.click("button[type='submit']")  
        self.assert_text(task_description, "ul")  


if __name__ == "__main__":
    with SB() as sb: 
        sb.open("http://127.0.0.1:5000/") 
        task_description = "hello,im abdalrahman"
        sb.type("input[name='task']", task_description)  
        sb.click("button[type='submit']")  
        time.sleep(5)#to show me the result
        sb.assert_text(task_description, "ul")  
